Warfare 1917 - النسخة العربية

التشغيل:
1) ويندوز: انقر مرتين على run-windows.bat   (يلزم تثبيت Python)
   ماك/لينكس: شغّل run-mac-linux.sh
2) سيفتح المتصفح على http://localhost:8000  (يلزم إنترنت في أول مرة لتحميل المشغّل Ruffle)
3) للتثبيت كتطبيق: قائمة Chrome > تثبيت التطبيق

الملفات:
warfare1917_ar.swf  = النسخة العربية + 100 نقطة مهارة (تظهر في حملة جديدة)
warfare1917.swf     = النسخة الإنجليزية + 100 نقطة مهارة
index.html          = صفحة التشغيل (زر عربي / English)
manifest.webmanifest, sw.js, icon-*.png = ملفات التطبيق
